#!/bin/bash

#SBATCH --job-name=dino_test_quick
#SBATCH --output=logs/dino_test_quick_%j.out
#SBATCH --error=logs/dino_test_quick_%j.err
#SBATCH --time=01:00:00
#SBATCH --mem=16G
#SBATCH --cpus-per-task=8
#SBATCH --account=csci_ga_2572-2025fa
#SBATCH --partition=c12m85-a100-1,c12m85-a100-2,c12m85-v100
#SBATCH --gres=gpu:1

echo "========================================"
echo "DINO Quick Test"
echo "========================================"
echo "Job ID: $SLURM_JOB_ID"
echo "GPU: $CUDA_VISIBLE_DEVICES"
echo "Node: $HOSTNAME"
echo "Start: $(date)"
echo ""

# Activate conda environment
source ~/.bashrc
conda activate /scratch/xh2919/envs/dlcapstone


# Set wandb API key
export WANDB_API_KEY='98503fbcd3e8c128194e02134b0f48080f58fc31'


echo "Python: $(which python)"
echo "Conda env: $CONDA_DEFAULT_ENV"
echo ""

# Create necessary directories
mkdir -p logs test_results_quick

echo "🧪 快速测试模型..."
echo ""

# 修改这里的checkpoint路径为你的实际路径
CHECKPOINT="./checkpoints_quick/dino_best.pt"

python test.py \
  --checkpoint $CHECKPOINT \
  --test_samples 2000 \
  --batch_size 128 \
  --num_workers 8 \
  --output_dir ./test_results_quick

echo ""
echo "✅ 测试完成！结果保存在 ./test_results_quick"
echo "End: $(date)"
