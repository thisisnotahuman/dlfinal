"""
DINO模型测试和评估
包含：特征提取、k-NN评估、可视化
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import argparse
import os
import numpy as np
from tqdm.auto import tqdm
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, classification_report
import matplotlib.pyplot as plt
from datasets import load_dataset

from model import create_dino_models
from load_data import ms_transform


@torch.no_grad()
def extract_features(model, dataloader, device):
    """
    提取模型特征
    
    Args:
        model: DINO模型
        dataloader: 数据加载器
        device: 设备
        
    Returns:
        features: 特征矩阵 (N, D)
        labels: 标签 (N,)
    """
    model.eval()
    all_features = []
    all_labels = []
    
    print("\n🔍 提取特征中...")
    for batch in tqdm(dataloader, desc="Feature extraction"):
        if isinstance(batch, dict):
            images = batch['image']
            labels = batch.get('label', None)
        elif isinstance(batch, (list, tuple)):
            images = batch[0]
            labels = batch[1] if len(batch) > 1 else None
        else:
            images = batch
            labels = None
        
        # 处理图像
        if not isinstance(images, torch.Tensor):
            # 如果是PIL图像列表
            transform = ms_transform()
            images = torch.stack([transform(img) for img in images])
        
        images = images.to(device)
        if images.dim() == 5:  # [B, 1, C, H, W]
            images = images.squeeze(1)
        
        # 提取特征（只用backbone）
        features = model.backbone(images)
        all_features.append(features.cpu())
        
        if labels is not None:
            if not isinstance(labels, torch.Tensor):
                labels = torch.tensor(labels)
            all_labels.append(labels.cpu())
    
    features = torch.cat(all_features, dim=0)
    labels = torch.cat(all_labels, dim=0) if all_labels else None
    
    print(f"✅ 特征提取完成！Shape: {features.shape}")
    return features.numpy(), labels.numpy() if labels is not None else None


def knn_evaluation(train_features, train_labels, test_features, test_labels, k=20):
    """
    k-NN评估
    
    Args:
        train_features: 训练特征
        train_labels: 训练标签
        test_features: 测试特征
        test_labels: 测试标签
        k: k-NN的k值
        
    Returns:
        accuracy: 准确率
        report: 分类报告
    """
    print(f"\n🎯 进行k-NN评估 (k={k})...")
    
    # L2归一化
    train_features = train_features / (np.linalg.norm(train_features, axis=1, keepdims=True) + 1e-8)
    test_features = test_features / (np.linalg.norm(test_features, axis=1, keepdims=True) + 1e-8)
    
    # k-NN分类器
    knn = KNeighborsClassifier(n_neighbors=k, metric='cosine')
    knn.fit(train_features, train_labels)
    
    # 预测
    predictions = knn.predict(test_features)
    accuracy = accuracy_score(test_labels, predictions)
    report = classification_report(test_labels, predictions)
    
    print(f"✅ k-NN准确率: {accuracy:.4f}")
    print("\n分类报告:")
    print(report)
    
    return accuracy, report


def visualize_features(features, labels, save_path='feature_visualization.png', n_samples=1000):
    """
    可视化特征分布（使用PCA降维）
    
    Args:
        features: 特征矩阵
        labels: 标签
        save_path: 保存路径
        n_samples: 可视化的样本数
    """
    from sklearn.decomposition import PCA
    
    print(f"\n📊 可视化特征分布...")
    
    # 随机采样
    if len(features) > n_samples:
        indices = np.random.choice(len(features), n_samples, replace=False)
        features = features[indices]
        labels = labels[indices] if labels is not None else None
    
    # PCA降维到2D
    pca = PCA(n_components=2)
    features_2d = pca.fit_transform(features)
    
    # 绘图
    plt.figure(figsize=(10, 8))
    if labels is not None:
        scatter = plt.scatter(features_2d[:, 0], features_2d[:, 1], 
                            c=labels, cmap='tab10', alpha=0.6, s=20)
        plt.colorbar(scatter, label='Class')
    else:
        plt.scatter(features_2d[:, 0], features_2d[:, 1], alpha=0.6, s=20)
    
    plt.xlabel(f'PC1 ({pca.explained_variance_ratio_[0]:.2%} variance)')
    plt.ylabel(f'PC2 ({pca.explained_variance_ratio_[1]:.2%} variance)')
    plt.title('DINO Feature Space Visualization (PCA)')
    plt.tight_layout()
    plt.savefig(save_path, dpi=150)
    plt.close()
    
    print(f"✅ 特征可视化已保存: {save_path}")


def compute_feature_statistics(features):
    """计算特征统计信息"""
    print("\n📈 特征统计信息:")
    print(f"  - Shape: {features.shape}")
    print(f"  - Mean: {features.mean():.4f}")
    print(f"  - Std: {features.std():.4f}")
    print(f"  - Min: {features.min():.4f}")
    print(f"  - Max: {features.max():.4f}")
    
    # 计算特征的L2范数
    norms = np.linalg.norm(features, axis=1)
    print(f"  - L2 Norm Mean: {norms.mean():.4f}")
    print(f"  - L2 Norm Std: {norms.std():.4f}")


def test_model(
    checkpoint_path,
    dataset_name='tsbpp/fall2025_deeplearning',
    img_size=96,
    batch_size=128,
    num_workers=4,
    device='cuda',
    test_samples=None,
    do_knn=False,
    knn_train_samples=5000,
    knn_test_samples=1000,
    k=20,
    output_dir='./test_results'
):
    """
    完整的测试流程
    
    Args:
        checkpoint_path: 模型checkpoint路径
        dataset_name: 数据集名称
        img_size: 图像尺寸
        batch_size: 批次大小
        num_workers: DataLoader工作进程数
        device: 设备
        test_samples: 测试样本数
        do_knn: 是否进行k-NN评估
        knn_train_samples: k-NN训练样本数
        knn_test_samples: k-NN测试样本数
        k: k-NN的k值
        output_dir: 输出目录
    """
    os.makedirs(output_dir, exist_ok=True)
    device = torch.device(device if torch.cuda.is_available() else 'cpu')
    
    print("\n" + "=" * 60)
    print("🧪 DINO模型测试")
    print("=" * 60)
    print(f"Checkpoint: {checkpoint_path}")
    print(f"设备: {device}")
    print(f"批次大小: {batch_size}")
    print("=" * 60)
    
    # 加载模型
    print("\n🔧 加载模型...")
    student, teacher, embed_dim = create_dino_models(device=device, img_size=img_size)
    
    checkpoint = torch.load(checkpoint_path, map_location=device)
    if 'student_state_dict' in checkpoint:
        student.load_state_dict(checkpoint['student_state_dict'])
        teacher.load_state_dict(checkpoint['teacher_state_dict'])
        print(f"✅ 加载checkpoint (Epoch {checkpoint.get('epoch', 'unknown')})")
    else:
        student.load_state_dict(checkpoint)
        print("✅ 加载模型权重")
    
    # 使用teacher模型进行评估（通常效果更好）
    model = teacher
    model.eval()
    
    # 加载数据
    print("\n📥 加载测试数据...")
    from torch.utils.data import DataLoader, Subset
    import random
    
    dataset = load_dataset(dataset_name)
    transform = ms_transform(img_size=img_size)
    
    # 创建测试集
    if test_samples and test_samples < len(dataset['train']):
        indices = random.sample(range(len(dataset['train'])), test_samples)
        test_subset = Subset(dataset['train'], indices)
    else:
        test_subset = dataset['train']
    
    from load_data import DINODatasetV2
    test_dataset = DINODatasetV2(test_subset, transform, lambda x: x)
    test_loader = DataLoader(
        test_dataset, 
        batch_size=batch_size, 
        shuffle=False,
        num_workers=num_workers,
        pin_memory=(num_workers > 0)
    )
    
    print(f"✅ 测试集大小: {len(test_dataset)}")
    
    # 提取特征
    features, labels = extract_features(model, test_loader, device)
    
    # 计算统计信息
    compute_feature_statistics(features)
    
    # 保存特征
    feature_path = os.path.join(output_dir, 'features.npz')
    np.savez(feature_path, features=features, labels=labels)
    print(f"\n💾 特征已保存: {feature_path}")
    
    # 可视化特征
    vis_path = os.path.join(output_dir, 'feature_visualization.png')
    visualize_features(features, labels, vis_path)
    
    # k-NN评估（如果有标签）
    if do_knn and labels is not None:
        print("\n" + "=" * 60)
        print("🎯 k-NN评估")
        print("=" * 60)
        
        # 划分训练测试集
        n_samples = len(features)
        indices = np.random.permutation(n_samples)
        train_indices = indices[:min(knn_train_samples, n_samples//2)]
        test_indices = indices[n_samples//2:n_samples//2+min(knn_test_samples, n_samples//2)]
        
        train_features = features[train_indices]
        train_labels = labels[train_indices]
        test_features = features[test_indices]
        test_labels = labels[test_indices]
        
        print(f"k-NN训练集: {len(train_features)} 样本")
        print(f"k-NN测试集: {len(test_features)} 样本")
        
        accuracy, report = knn_evaluation(
            train_features, train_labels,
            test_features, test_labels,
            k=k
        )
        
        # 保存结果
        result_path = os.path.join(output_dir, 'knn_results.txt')
        with open(result_path, 'w') as f:
            f.write(f"k-NN Evaluation Results (k={k})\n")
            f.write("=" * 60 + "\n")
            f.write(f"Accuracy: {accuracy:.4f}\n\n")
            f.write("Classification Report:\n")
            f.write(report)
        print(f"\n💾 k-NN结果已保存: {result_path}")
    
    print("\n" + "=" * 60)
    print("✅ 测试完成！")
    print(f"结果保存在: {output_dir}")
    print("=" * 60)


def main():
    parser = argparse.ArgumentParser(description='DINO Model Testing and Evaluation')
    
    # 必需参数
    parser.add_argument('--checkpoint', type=str, required=True,
                       help='模型checkpoint路径')
    
    # 数据参数
    parser.add_argument('--dataset', type=str, default='tsbpp/fall2025_deeplearning',
                       help='Hugging Face数据集名称')
    parser.add_argument('--img_size', type=int, default=96,
                       help='输入图像尺寸')
    parser.add_argument('--batch_size', type=int, default=128,
                       help='批次大小')
    parser.add_argument('--num_workers', type=int, default=4,
                       help='DataLoader工作进程数')
    parser.add_argument('--test_samples', type=int, default=None,
                       help='测试样本数 (None=使用全部数据)')
    
    # k-NN评估参数
    parser.add_argument('--do_knn', action='store_true',
                       help='是否进行k-NN评估')
    parser.add_argument('--knn_train_samples', type=int, default=5000,
                       help='k-NN训练样本数')
    parser.add_argument('--knn_test_samples', type=int, default=1000,
                       help='k-NN测试样本数')
    parser.add_argument('--k', type=int, default=20,
                       help='k-NN的k值')
    
    # 其他参数
    parser.add_argument('--device', type=str, default='cuda',
                       help='设备 (cuda/cpu)')
    parser.add_argument('--output_dir', type=str, default='./test_results',
                       help='输出目录')
    
    args = parser.parse_args()
    
    # 检查checkpoint是否存在
    if not os.path.exists(args.checkpoint):
        print(f"❌ 错误: Checkpoint不存在: {args.checkpoint}")
        return
    
    # 运行测试
    test_model(
        checkpoint_path=args.checkpoint,
        dataset_name=args.dataset,
        img_size=args.img_size,
        batch_size=args.batch_size,
        num_workers=args.num_workers,
        device=args.device,
        test_samples=args.test_samples,
        do_knn=args.do_knn,
        knn_train_samples=args.knn_train_samples,
        knn_test_samples=args.knn_test_samples,
        k=args.k,
        output_dir=args.output_dir
    )


if __name__ == "__main__":
    main()
