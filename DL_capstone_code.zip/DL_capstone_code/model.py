"""
DINO模型定义
包含：ViT backbone, DINO Head, DINO Loss
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import timm


class DINOHead(nn.Module):
    """DINO投影头"""
    def __init__(self, in_dim, out_dim=8192, hidden_dim=2048, bottleneck_dim=256):
        super().__init__()
        self.mlp = nn.Sequential(
            nn.Linear(in_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, bottleneck_dim)
        )
        self.last_layer = nn.utils.weight_norm(nn.Linear(bottleneck_dim, out_dim, bias=False))
        self.last_layer.weight_g.data.fill_(1)
        self.last_layer.weight_g.requires_grad = False

    def forward(self, x):
        x = self.mlp(x)
        x = F.normalize(x, dim=-1, p=2)
        x = self.last_layer(x)
        return x


class DINOModel(nn.Module):
    """完整DINO模型 = Backbone + Head"""
    def __init__(self, backbone, head):
        super().__init__()
        self.backbone = backbone
        self.head = head
    
    def forward(self, x):
        return self.head(self.backbone(x))


class DINOLoss(nn.Module):
    """DINO对比学习损失函数"""
    def __init__(self, out_dim=8192, teacher_temp=0.04, student_temp=0.1, center_momentum=0.9):
        super().__init__()
        self.student_temp = student_temp
        self.teacher_temp = teacher_temp
        self.center_momentum = center_momentum
        self.register_buffer("center", torch.zeros(1, out_dim))
        
    def forward(self, student_output, teacher_output):
        student_out = [s / self.student_temp for s in student_output]
        teacher_out = [(t - self.center.to(t.device)) / self.teacher_temp for t in teacher_output]
        teacher_out = [F.softmax(t, dim=-1).detach() for t in teacher_out]
        
        total_loss = 0
        n_loss_terms = 0
        
        for iq, q in enumerate(teacher_out):
            for v in range(len(student_out)):
                if v == iq:
                    continue
                loss = torch.sum(-q * F.log_softmax(student_out[v], dim=-1), dim=-1)
                total_loss += loss.mean()
                n_loss_terms += 1
                
        total_loss /= n_loss_terms
        self.update_center(teacher_output)
        return total_loss
    
    @torch.no_grad()
    def update_center(self, teacher_output):
        batch_center = torch.cat(teacher_output).mean(dim=0, keepdim=True)
        self.center = self.center.to(batch_center.device) * self.center_momentum + batch_center * (1 - self.center_momentum)


def create_dino_models(device='cuda', img_size=96, out_dim=8192):
    """
    创建Student和Teacher模型
    
    Args:
        device: 设备 ('cuda' or 'cpu')
        img_size: 输入图像尺寸
        out_dim: DINO head输出维度
        
    Returns:
        student: Student模型
        teacher: Teacher模型
        embed_dim: Backbone特征维度
    """
    # 创建ViT-Base/16 backbone
    student_backbone = timm.create_model(
        'vit_base_patch16_224', 
        pretrained=False, 
        img_size=img_size, 
        num_classes=0, 
        drop_path_rate=0.1
    )
    teacher_backbone = timm.create_model(
        'vit_base_patch16_224', 
        pretrained=False,
        img_size=img_size, 
        num_classes=0, 
        drop_path_rate=0.1
    )
    
    embed_dim = student_backbone.num_features
    
    # 创建DINO Head
    student_head = DINOHead(embed_dim, out_dim=out_dim)
    teacher_head = DINOHead(embed_dim, out_dim=out_dim)
    
    # 组装完整模型
    student = DINOModel(student_backbone, student_head).to(device)
    teacher = DINOModel(teacher_backbone, teacher_head).to(device)
    
    # Teacher初始化为Student的副本
    teacher.load_state_dict(student.state_dict())
    
    # Teacher不需要梯度
    for p in teacher.parameters():
        p.requires_grad = False
    
    # 打印参数量
    student_params = sum(p.numel() for p in student.parameters()) / 1e6
    print(f"✅ 模型创建成功！")
    print(f"   参数量: {student_params:.1f}M")
    print(f"   设备: {device}")
    
    assert student_params < 100, f"参数超限: {student_params:.1f}M > 100M"
    
    return student, teacher, embed_dim


if __name__ == "__main__":
    # 测试模型创建
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    print(f"使用设备: {device}")
    
    student, teacher, embed_dim = create_dino_models(device=device)
    
    # 测试前向传播
    batch_size = 4
    x = torch.randn(batch_size, 3, 96, 96).to(device)
    
    with torch.no_grad():
        out_s = student(x)
        out_t = teacher(x)
    
    print(f"✅ 模型测试通过")
    print(f"   输入shape: {x.shape}")
    print(f"   Student输出shape: {out_s.shape}")
    print(f"   Teacher输出shape: {out_t.shape}")
