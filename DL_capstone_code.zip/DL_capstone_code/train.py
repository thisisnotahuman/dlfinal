"""
DINO训练函数
包含：训练循环, 评估, 可视化
"""

import torch
import torch.nn as nn
import numpy as np
from tqdm.auto import tqdm
import time
import os
import matplotlib.pyplot as plt

try:
    import wandb
    WANDB_AVAILABLE = True
except ImportError:
    WANDB_AVAILABLE = False
    print("⚠️  wandb未安装，将跳过wandb日志记录")


def cosine_scheduler(base_value, final_value, epochs, niter_per_ep, warmup_epochs=0):
    """余弦学习率调度"""
    warmup_schedule = np.array([])
    warmup_iters = warmup_epochs * niter_per_ep
    if warmup_epochs > 0:
        warmup_schedule = np.linspace(0, base_value, warmup_iters)
    iters = np.arange(epochs * niter_per_ep - warmup_iters)
    schedule = final_value + 0.5 * (base_value - final_value) * (1 + np.cos(np.pi * iters / len(iters)))
    schedule = np.concatenate((warmup_schedule, schedule))
    return schedule


@torch.no_grad()
def update_teacher(student, teacher, momentum):
    """EMA更新Teacher模型"""
    for param_s, param_t in zip(student.parameters(), teacher.parameters()):
        param_t.data.mul_(momentum).add_(param_s.data, alpha=1 - momentum)


def train_one_epoch(student, teacher, train_loader, criterion, optimizer, 
                    lr_schedule, momentum_schedule, epoch, device, two_view_aug, use_wandb=False):
    """训练一个epoch"""
    student.train()
    teacher.eval()
    total_loss = 0
    
    pbar = tqdm(train_loader, desc=f"Epoch {epoch+1}", position=1, leave=False)
    
    for batch_idx, img_batch in enumerate(pbar):
        it = len(train_loader) * epoch + batch_idx
        
        # 更新学习率
        for param_group in optimizer.param_groups:
            param_group['lr'] = lr_schedule[it]
        
        img_batch = img_batch.squeeze(1).to(device)
        
        # 应用双视图增强
        augmented = two_view_aug(img_batch)
        view1, view2 = augmented[:, 0], augmented[:, 1]
        
        # Forward
        with torch.no_grad():
            teacher_output = [teacher(view1), teacher(view2)]
        student_output = [student(view1), student(view2)]
        
        # Loss
        loss = criterion(student_output, teacher_output)
        
        # Backward
        optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(student.parameters(), max_norm=3.0)
        optimizer.step()
        
        # 更新Teacher
        momentum = momentum_schedule[it]
        update_teacher(student, teacher, momentum)
        
        total_loss += loss.item()
        pbar.set_postfix({
            'loss': f'{loss.item():.4f}', 
            'lr': f'{lr_schedule[it]:.8f}'
        })
        
        # 记录到wandb（每个batch）
        if use_wandb and WANDB_AVAILABLE:
            wandb.log({
                'train/loss_step': loss.item(),
                'train/lr': lr_schedule[it],
                'train/momentum': momentum,
                'train/step': it
            })
    
    pbar.close()
    return total_loss / len(train_loader)


@torch.no_grad()
def evaluate(student, teacher, eval_loader, criterion, device, two_view_aug, use_wandb=False, epoch=0):
    """评估模型"""
    student.eval()
    teacher.eval()
    total_loss = 0
    
    pbar = tqdm(eval_loader, desc="Evaluating", position=1, leave=False)
    
    for img_batch in pbar:
        img_batch = img_batch.squeeze(1).to(device)
        
        # 应用增强
        augmented = two_view_aug(img_batch)
        view1, view2 = augmented[:, 0], augmented[:, 1]
        
        # Forward
        teacher_output = [teacher(view1), teacher(view2)]
        student_output = [student(view1), student(view2)]
        
        # Loss
        loss = criterion(student_output, teacher_output)
        total_loss += loss.item()
        
        pbar.set_postfix({'loss': f'{loss.item():.4f}'})
    
    pbar.close()
    avg_loss = total_loss / len(eval_loader)
    
    # 记录到wandb
    if use_wandb and WANDB_AVAILABLE:
        wandb.log({
            'eval/loss': avg_loss,
            'eval/epoch': epoch
        })
    
    return avg_loss


def plot_training_validation(train_losses, eval_losses, save_path='loss_curve.png'):
    """绘制训练和验证曲线"""
    plt.figure(figsize=(10, 6))
    epochs_range = range(1, len(train_losses) + 1)
    
    plt.plot(epochs_range, train_losses, 'b-o', label='Training Loss', 
             linewidth=2, markersize=6)
    
    if eval_losses:
        plt.plot(epochs_range, eval_losses, 'r-s', label='Validation Loss', 
                linewidth=2, markersize=6)
    
    plt.xlabel('Epoch', fontsize=12)
    plt.ylabel('Loss', fontsize=12)
    plt.title('DINO Training & Validation Loss', fontsize=14)
    plt.legend(fontsize=11)
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(save_path, dpi=150)
    plt.close()
    print(f"✅ 曲线已保存: {save_path}")


def train_dino(
    student, teacher, train_loader, eval_loader, criterion, optimizer,
    lr_schedule, momentum_schedule, epochs, device, two_view_aug,
    eval_freq=1, save_freq=5, checkpoint_dir='./checkpoints', use_wandb=False, wandb_project='dino-training'
):
    """
    完整训练流程
    
    Args:
        eval_freq: 每几个epoch评估一次
        save_freq: 每几个epoch保存一次
        use_wandb: 是否使用wandb日志记录
        wandb_project: wandb项目名称
    """
    os.makedirs(checkpoint_dir, exist_ok=True)
    
    # 初始化wandb
    if use_wandb and WANDB_AVAILABLE:
        wandb.init(
            project=wandb_project,
            config={
                'epochs': epochs,
                'batch_size': train_loader.batch_size,
                'learning_rate': optimizer.param_groups[0]['lr'],
                'device': str(device),
                'eval_freq': eval_freq,
                'save_freq': save_freq,
            },
            tags=['dino', 'self-supervised', 'vision-transformer']
        )
        # 监控系统资源（GPU利用率、显存等）
        wandb.watch(student, log='all', log_freq=100)
        print("✅ Wandb已初始化，可在网页查看训练监控")
    elif use_wandb and not WANDB_AVAILABLE:
        print("⚠️  wandb未安装，请运行: pip install wandb")
        use_wandb = False
    
    print("\n" + "=" * 60)
    print("🚀 开始DINO训练")
    print("=" * 60)
    print(f"总epochs: {epochs}")
    print(f"每个epoch的batches: {len(train_loader)}")
    print(f"设备: {device}")
    print(f"评估频率: 每{eval_freq}个epochs")
    print(f"保存频率: 每{save_freq}个epochs")
    print(f"Wandb监控: {'✓ 启用' if use_wandb else '✗ 禁用'}")
    print("=" * 60)
    
    best_loss = float('inf')
    train_losses = []
    eval_losses = []
    
    start_time = time.time()
    
    # 训练循环
    epoch_pbar = tqdm(range(epochs), desc="Training Progress", position=0)
    
    for epoch in epoch_pbar:
        epoch_start = time.time()
        
        # 训练一个epoch
        train_loss = train_one_epoch(
            student, teacher, train_loader, criterion, optimizer,
            lr_schedule, momentum_schedule, epoch, device, two_view_aug, use_wandb=use_wandb
        )
        train_losses.append(train_loss)
        
        # 评估
        eval_loss = None
        if eval_loader is not None and (epoch + 1) % eval_freq == 0:
            eval_loss = evaluate(student, teacher, eval_loader, criterion, device, two_view_aug, 
                               use_wandb=use_wandb, epoch=epoch)
            eval_losses.append(eval_loss)
        
        epoch_time = time.time() - epoch_start
        
        # 记录epoch级别的指标到wandb
        if use_wandb and WANDB_AVAILABLE:
            log_dict = {
                'train/loss_epoch': train_loss,
                'train/epoch': epoch + 1,
                'train/epoch_time': epoch_time
            }
            if eval_loss is not None:
                log_dict['eval/loss_epoch'] = eval_loss
            
            # 记录GPU使用情况（如果有GPU）
            if torch.cuda.is_available():
                log_dict['system/gpu_memory_allocated_GB'] = torch.cuda.memory_allocated() / 1e9
                log_dict['system/gpu_memory_reserved_GB'] = torch.cuda.memory_reserved() / 1e9
                log_dict['system/gpu_utilization'] = torch.cuda.utilization()
            
            wandb.log(log_dict)
        
        # 更新进度条
        msg = f"Epoch {epoch+1}/{epochs} | Train Loss: {train_loss:.4f}"
        if eval_loss is not None:
            msg += f" | Val Loss: {eval_loss:.4f}"
        msg += f" | Time: {epoch_time:.1f}s"
        epoch_pbar.set_postfix_str(msg)
        
        # 保存checkpoint
        if (epoch + 1) % save_freq == 0 or epoch == epochs - 1:
            checkpoint = {
                'epoch': epoch,
                'student_state_dict': student.state_dict(),
                'teacher_state_dict': teacher.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'train_loss': train_loss,
                'eval_loss': eval_loss,
                'train_losses': train_losses,
                'eval_losses': eval_losses
            }
            
            ckpt_path = os.path.join(checkpoint_dir, f'dino_epoch_{epoch+1}.pth')
            torch.save(checkpoint, ckpt_path)
            
            # 保存最佳模型
            current_loss = eval_loss if eval_loss is not None else train_loss
            if current_loss < best_loss:
                best_loss = current_loss
                best_path = os.path.join(checkpoint_dir, 'dino_best.pth')
                torch.save(checkpoint, best_path)
    
    epoch_pbar.close()
    
    total_time = time.time() - start_time
    print("\n" + "=" * 60)
    print("✅ 训练完成！")
    print(f"总时间: {total_time / 3600:.2f}小时")
    print(f"最佳loss: {best_loss:.4f}")
    print("=" * 60)
    
    # 绘制曲线
    curve_path = os.path.join(checkpoint_dir, 'loss_curve.png')
    plot_training_validation(train_losses, eval_losses, curve_path)
    
    # 上传曲线图到wandb
    if use_wandb and WANDB_AVAILABLE:
        wandb.log({
            'summary/total_time_hours': total_time / 3600,
            'summary/best_loss': best_loss,
            'summary/final_train_loss': train_losses[-1],
            'charts/loss_curve': wandb.Image(curve_path)
        })
        wandb.finish()
        print("✅ Wandb日志已保存并关闭")
    
    return train_losses, eval_losses
