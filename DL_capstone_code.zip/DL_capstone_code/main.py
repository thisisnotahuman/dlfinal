"""
DINO训练主程序入口
运行示例：
    python main.py --train_samples 4000 --eval_samples 1000 --epochs 10
    python main.py --epochs 100 --batch_size 64 --lr 0.0005
"""

import torch
import argparse

from model import create_dino_models, DINOLoss
from load_data import load_dino_data
from train import cosine_scheduler, train_dino


def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='DINO Self-Supervised Learning Training')
    
    # 数据参数
    parser.add_argument('--dataset', type=str, default='tsbpp/fall2025_deeplearning',
                       help='Hugging Face数据集名称')
    parser.add_argument('--dataset_type', type=str, default='huggingface',
                       choices=['huggingface', 'cifar10', 'cifar100'],
                       help='数据集类型: huggingface, cifar10, cifar100')
    parser.add_argument('--img_size', type=int, default=96,
                       help='输入图像尺寸')
    parser.add_argument('--batch_size', type=int, default=64,
                       help='批次大小')
    parser.add_argument('--num_workers', type=int, default=0,
                       help='DataLoader工作进程数 (Windows建议0)')
    parser.add_argument('--train_samples', type=int, default=None,
                       help='训练样本数 (None=使用全部数据)')
    parser.add_argument('--eval_samples', type=int, default=None,
                       help='验证样本数 (None=不创建验证集)')
    
    # 训练参数
    parser.add_argument('--epochs', type=int, default=100,
                       help='训练轮数')
    parser.add_argument('--lr', type=float, default=0.0005,
                       help='基础学习率')
    parser.add_argument('--weight_decay', type=float, default=0.04,
                       help='权重衰减')
    parser.add_argument('--warmup_epochs', type=int, default=10,
                       help='学习率warmup轮数')
    
    # 其他参数
    parser.add_argument('--eval_freq', type=int, default=1,
                       help='评估频率 (每几个epoch评估一次)')
    parser.add_argument('--save_freq', type=int, default=10,
                       help='保存频率 (每几个epoch保存一次)')
    parser.add_argument('--checkpoint_dir', type=str, default='./dino_checkpoints',
                       help='checkpoint保存目录')
    parser.add_argument('--device', type=str, default='cuda',
                       help='训练设备 (cuda/cpu)')
    parser.add_argument('--use_wandb', action='store_true',
                       help='启用Weights & Biases日志记录和GPU监控')
    parser.add_argument('--wandb_project', type=str, default='dino-training',
                       help='Wandb项目名称')
    
    args = parser.parse_args()
    
    # 设备检查
    device = torch.device(args.device if torch.cuda.is_available() else 'cpu')
    print("\n" + "=" * 60)
    print("🖥️  设备信息")
    print("=" * 60)
    print(f"使用设备: {device}")
    if torch.cuda.is_available():
        print(f"✓ GPU名称: {torch.cuda.get_device_name(0)}")
        print(f"✓ CUDA版本: {torch.version.cuda}")
        print(f"✓ GPU显存: {torch.cuda.get_device_properties(0).total_memory / 1024**3:.2f} GB")
    else:
        print("⚠️  WARNING: GPU不可用，将使用CPU训练（速度会非常慢）")
    print("=" * 60)
    
    # 加载数据
    train_loader, eval_loader, base_transform, two_view_aug = load_dino_data(
        dataset_name=args.dataset,
        dataset_type=args.dataset_type,
        img_size=args.img_size,
        batch_size=args.batch_size,
        num_workers=args.num_workers,
        train_samples=args.train_samples,
        eval_samples=args.eval_samples
    )
    
    # 创建模型
    print("\n" + "=" * 60)
    print("🔧 创建模型")
    print("=" * 60)
    student, teacher, embed_dim = create_dino_models(device=device, img_size=args.img_size)
    criterion = DINOLoss(out_dim=8192).to(device)
    print(f"✓ DINO Loss已创建")
    
    # 优化器和调度器
    lr = args.lr * args.batch_size / 256  # 根据batch size调整学习率
    optimizer = torch.optim.AdamW(student.parameters(), lr=lr, weight_decay=args.weight_decay)
    
    lr_schedule = cosine_scheduler(
        base_value=lr,
        final_value=1e-6,
        epochs=args.epochs,
        niter_per_ep=len(train_loader),
        warmup_epochs=args.warmup_epochs
    )
    momentum_schedule = cosine_scheduler(
        base_value=0.996,
        final_value=1.0,
        epochs=args.epochs,
        niter_per_ep=len(train_loader)
    )
    
    print("\n" + "=" * 60)
    print("⚙️  训练配置")
    print("=" * 60)
    print(f"训练轮数: {args.epochs}")
    print(f"批次大小: {args.batch_size}")
    print(f"学习率 (调整后): {lr:.6f}")
    print(f"权重衰减: {args.weight_decay}")
    print(f"Warmup轮数: {args.warmup_epochs}")
    print(f"评估频率: 每{args.eval_freq}个epochs")
    print(f"保存频率: 每{args.save_freq}个epochs")
    print(f"保存目录: {args.checkpoint_dir}")
    print(f"Wandb监控: {'✓ 启用' if args.use_wandb else '✗ 禁用'}")
    if args.use_wandb:
        print(f"Wandb项目: {args.wandb_project}")
    print("=" * 60)
    
    # 估算训练时间
    if args.train_samples:
        batches_per_epoch = args.train_samples // args.batch_size
    else:
        batches_per_epoch = len(train_loader)
    
    print(f"\n⏱️  预计训练时间:")
    print(f"   每个epoch约 {batches_per_epoch} 个batches")
    print(f"   如果每batch需要30秒，每epoch约 {batches_per_epoch * 30 / 60:.1f} 分钟")
    print(f"   总共需要约 {batches_per_epoch * 30 * args.epochs / 3600:.1f} 小时")
    
    # 开始训练
    train_losses, eval_losses = train_dino(
        student=student,
        teacher=teacher,
        train_loader=train_loader,
        eval_loader=eval_loader,
        criterion=criterion,
        optimizer=optimizer,
        lr_schedule=lr_schedule,
        momentum_schedule=momentum_schedule,
        epochs=args.epochs,
        device=device,
        two_view_aug=two_view_aug,
        eval_freq=args.eval_freq,
        save_freq=args.save_freq,
        checkpoint_dir=args.checkpoint_dir,
        use_wandb=args.use_wandb,
        wandb_project=args.wandb_project
    )
    
    print("\n🎉 训练全部完成！")


if __name__ == "__main__":
    main()
