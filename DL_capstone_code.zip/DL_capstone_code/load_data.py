"""
数据加载和增强
包含：数据增强pipeline, Dataset, DataLoader创建
"""

import torch
import torchvision.transforms as T
from torchvision.models import ResNeXt50_32X4D_Weights
from PIL import ImageOps
from torch.utils.data import Dataset, DataLoader, Subset
from datasets import load_dataset
import random


def build_two_view_augment(
    img_size: int,
    strength: str = "strong",
    mean=(0.485, 0.456, 0.406),
    std=(0.229, 0.224, 0.225),
):
    """
    构建双视图增强pipeline
    
    Args:
        img_size: 图像尺寸
        strength: 增强强度 ('strong', 'medium', 'weak')
        mean: 归一化均值
        std: 归一化标准差
        
    Returns:
        two_crops: 双视图增强函数
    """
    strength = strength.lower()
    if strength not in {"strong", "medium", "weak"}:
        raise ValueError(f"strength must be strong/medium/weak, got {strength!r}")

    weights = ResNeXt50_32X4D_Weights.IMAGENET1K_V1
    base_mean = torch.tensor(weights.transforms().mean).view(1, 3, 1, 1)
    base_std = torch.tensor(weights.transforms().std).view(1, 3, 1, 1)
    mean_t = torch.tensor(mean).view(1, 3, 1, 1)
    std_t = torch.tensor(std).view(1, 3, 1, 1)

    # 不同强度的增强配置
    if strength == "strong":
        aug_cfg = dict(
            use_rrc=True, cj=(0.8, 0.8, 0.8, 0.2), p_cj=0.8, p_gray=0.2,
            blur_p1=1.0, blur_p2=0.1, solarize_p2=0.2,
        )
    elif strength == "medium":
        aug_cfg = dict(
            use_rrc=False, cj=(0.4, 0.4, 0.3, 0.1), p_cj=0.7, p_gray=0.15,
            blur_p1=0.6, blur_p2=0.1, solarize_p2=0.0,
        )
    else:  # weak
        aug_cfg = dict(
            use_rrc=False, cj=(0.3, 0.3, 0.2, 0.05), p_cj=0.5, p_gray=0.1,
            blur_p1=0.3, blur_p2=0.0, solarize_p2=0.0,
        )

    k = max(3, int(0.1 * img_size) // 2 * 2 + 1)
    to_pil = T.ToPILImage()

    def build_pipeline(view_idx: int):
        """构建单个视图的增强pipeline"""
        ops = []
        if aug_cfg["use_rrc"]:
            ops.append(T.RandomResizedCrop(size=img_size, scale=(0.2, 1.0), 
                                          interpolation=T.InterpolationMode.BILINEAR))
        else:
            ops.extend([
                T.Resize(img_size, interpolation=T.InterpolationMode.BICUBIC),
                T.CenterCrop(img_size),
            ])
        ops.append(T.RandomHorizontalFlip(p=0.5))
        ops.append(T.RandomApply([T.ColorJitter(*aug_cfg["cj"])], p=aug_cfg["p_cj"]))
        ops.append(T.RandomGrayscale(p=aug_cfg["p_gray"]))
        
        blur_p = aug_cfg["blur_p1"] if view_idx == 0 else aug_cfg["blur_p2"]
        if blur_p > 0:
            ops.append(T.RandomApply([T.GaussianBlur(kernel_size=k, sigma=(0.1, 2.0))], p=blur_p))
        
        if view_idx == 1 and aug_cfg["solarize_p2"] > 0:
            ops.append(T.Lambda(lambda img: ImageOps.solarize(img, threshold=128) 
                               if torch.rand(1) < aug_cfg["solarize_p2"] else img))
        ops.append(T.ToTensor())
        return T.Compose(ops)

    pip_v1 = build_pipeline(0)
    pip_v2 = build_pipeline(1)

    def two_crops(frames: torch.Tensor) -> torch.Tensor:
        """应用双视图增强"""
        device = frames.device
        mean_base = base_mean.to(device)
        std_base = base_std.to(device)

        # Denormalize
        x = frames * std_base + mean_base
        x = torch.clamp(x, 0.0, 1.0).cpu()

        # 顺序处理（避免多进程冲突）
        def _proc_single(img_tensor):
            pil = to_pil(img_tensor.float())
            out1 = pip_v1(pil)
            out2 = pip_v2(pil)
            return out1, out2

        results = [_proc_single(x[i]) for i in range(x.size(0))]
        v1_list, v2_list = zip(*results)

        v1 = torch.stack(v1_list, dim=0).contiguous()
        v2 = torch.stack(v2_list, dim=0).contiguous()

        # Normalize
        mean_custom_cpu = mean_t.cpu()
        std_custom_cpu = std_t.cpu()
        
        v1 = (v1 - mean_custom_cpu.squeeze(0)) / std_custom_cpu.squeeze(0)
        v2 = (v2 - mean_custom_cpu.squeeze(0)) / std_custom_cpu.squeeze(0)

        # Stack并移回原始device
        result = torch.stack([v1, v2], dim=1)
        return result.to(device)

    return two_crops


def ms_transform(img_size=96):
    """标准变换（用于base transform）"""
    w = ResNeXt50_32X4D_Weights.IMAGENET1K_V1
    mean, std = w.transforms().mean, w.transforms().std
    return T.Compose([
        T.Resize(img_size, interpolation=T.InterpolationMode.BICUBIC),
        T.CenterCrop(img_size),
        T.ToTensor(),
        T.Normalize(mean, std),
    ])


class DINODatasetV2(Dataset):
    """DINO数据集"""
    def __init__(self, hf_dataset, base_transform, two_view_augment_fn):
        self.dataset = hf_dataset
        self.base_transform = base_transform
        self.two_view_augment = two_view_augment_fn
        
    def __len__(self):
        return len(self.dataset)
    
    def __getitem__(self, idx):
        img = self.dataset[idx]['image']
        if img.mode != 'RGB':
            img = img.convert('RGB')
        img_tensor = self.base_transform(img)
        img_tensor = img_tensor.unsqueeze(0)  # [1, 3, H, W]
        return img_tensor


def load_dino_data(
    dataset_name="tsbpp/fall2025_deeplearning",
    dataset_type="huggingface",
    img_size=96,
    batch_size=64,
    num_workers=0,
    train_samples=None,
    eval_samples=None,
    strength="strong"
):
    """
    加载DINO训练数据
    
    Args:
        dataset_name: Hugging Face数据集名称（仅当dataset_type='huggingface'时使用）
        dataset_type: 数据集类型 ('huggingface', 'cifar10', 'cifar100')
        img_size: 图像尺寸
        batch_size: 批次大小
        num_workers: DataLoader工作进程数
        train_samples: 训练样本数（None=全部）
        eval_samples: 验证样本数（None=不创建验证集）
        strength: 增强强度
        
    Returns:
        train_loader: 训练DataLoader
        eval_loader: 验证DataLoader (如果eval_samples不为None)
        base_transform: 基础变换
        two_view_aug: 双视图增强函数
    """
    print("=" * 60)
    print("🔥 开始加载数据...")
    print("=" * 60)
    
    # 加载数据集
    if dataset_type == "cifar10":
        print("📥 加载 CIFAR-10 数据集...")
        from torchvision.datasets import CIFAR10
        train_data = CIFAR10(root='./data', train=True, download=True, transform=None)
        test_data = CIFAR10(root='./data', train=False, download=True, transform=None)
        # 转换为类似HF的格式
        class CIFARWrapper:
            def __init__(self, cifar_dataset):
                self.data = cifar_dataset
            def __len__(self):
                return len(self.data)
            def __getitem__(self, idx):
                img, label = self.data[idx]
                return {'image': img, 'label': label}
        dataset = {'train': CIFARWrapper(train_data), 'test': CIFARWrapper(test_data)}
        print(f"✓ CIFAR-10 训练集: {len(dataset['train'])} 张，测试集: {len(dataset['test'])} 张")
    elif dataset_type == "cifar100":
        print("📥 加载 CIFAR-100 数据集...")
        from torchvision.datasets import CIFAR100
        train_data = CIFAR100(root='./data', train=True, download=True, transform=None)
        test_data = CIFAR100(root='./data', train=False, download=True, transform=None)
        class CIFARWrapper:
            def __init__(self, cifar_dataset):
                self.data = cifar_dataset
            def __len__(self):
                return len(self.data)
            def __getitem__(self, idx):
                img, label = self.data[idx]
                return {'image': img, 'label': label}
        dataset = {'train': CIFARWrapper(train_data), 'test': CIFARWrapper(test_data)}
        print(f"✓ CIFAR-100 训练集: {len(dataset['train'])} 张，测试集: {len(dataset['test'])} 张")
    else:  # huggingface
        print(f"📥 从Hugging Face下载数据集: {dataset_name}...")
        dataset = load_dataset(dataset_name)
        print(f"✓ 数据集大小: {len(dataset['train'])} 张图片")
    
    # 创建transforms
    base_transform = ms_transform(img_size=img_size)
    two_view_aug = build_two_view_augment(img_size=img_size, strength=strength)
    print(f"✓ 增强策略: {strength}")
    
    # 准备训练集
    if train_samples is not None:
        print(f"\n📊 准备训练数据（采样 {train_samples} 张）...")
        train_indices = random.sample(range(len(dataset['train'])), train_samples)
        train_subset = Subset(dataset['train'], train_indices)
    else:
        print(f"\n📊 准备训练数据（使用全部数据）...")
        train_subset = dataset['train']
    
    train_dataset = DINODatasetV2(train_subset, base_transform, two_view_aug)
    print(f"✓ 训练集创建完成，大小: {len(train_dataset)}")
    
    # 创建训练DataLoader
    train_loader = DataLoader(
        train_dataset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers,
        pin_memory=(num_workers > 0),
        drop_last=True
    )
    print(f"✓ 训练 DataLoader 创建完成，batches: {len(train_loader)}")
    
    # 准备验证集（如果需要）
    eval_loader = None
    if eval_samples is not None:
        print(f"\n📊 准备验证数据（采样 {eval_samples} 张）...")
        all_indices = set(range(len(dataset['train'])))
        if train_samples is not None:
            remaining_indices = list(all_indices - set(train_indices))
        else:
            remaining_indices = list(range(len(dataset['train'])))
        
        eval_indices = random.sample(remaining_indices, min(eval_samples, len(remaining_indices)))
        eval_subset = Subset(dataset['train'], eval_indices)
        eval_dataset = DINODatasetV2(eval_subset, base_transform, two_view_aug)
        print(f"✓ 验证集创建完成，大小: {len(eval_dataset)}")
        
        eval_loader = DataLoader(
            eval_dataset,
            batch_size=batch_size,
            shuffle=False,
            num_workers=num_workers,
            pin_memory=(num_workers > 0),
            drop_last=False
        )
        print(f"✓ 验证 DataLoader 创建完成，batches: {len(eval_loader)}")
    
    print("=" * 60)
    print("✅ 数据加载完成！")
    print("=" * 60)
    
    return train_loader, eval_loader, base_transform, two_view_aug


if __name__ == "__main__":
    # 测试数据加载
    print("测试数据加载...")
    
    train_loader, eval_loader, base_transform, two_view_aug = load_dino_data(
        img_size=96,
        batch_size=64,
        num_workers=0,
        train_samples=1000,
        eval_samples=200,
        strength="strong"
    )
    
    # 测试一个batch
    print("\n测试DataLoader...")
    for batch in train_loader:
        print(f"Batch shape: {batch.shape}")
        break
    
    print("✅ 数据加载测试通过！")
