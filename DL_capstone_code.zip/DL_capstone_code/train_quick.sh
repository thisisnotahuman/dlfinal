#!/bin/bash

#SBATCH --job-name=dino_quick
#SBATCH --output=logs/dino_quick_%j.out
#SBATCH --error=logs/dino_quick_%j.err
#SBATCH --time=02:00:00
#SBATCH --mem=32G
#SBATCH --cpus-per-task=8
#SBATCH --account=csci_ga_2572-2025fa
#SBATCH --partition=c12m85-a100-1,c12m85-a100-2,c12m85-v100
#SBATCH --gres=gpu:1

echo "========================================"
echo "DINO Quick Training Test"
echo "========================================"
echo "Job ID: $SLURM_JOB_ID"
echo "GPU: $CUDA_VISIBLE_DEVICES"
echo "Node: $HOSTNAME"
echo "Start: $(date)"
echo ""

# Activate conda environment
source ~/.bashrc
conda activate /scratch/xh2919/envs/dlcapstone

# Set wandb API key
export WANDB_API_KEY='98503fbcd3e8c128194e02134b0f48080f58fc31'

echo "Python: $(which python)"
echo "Conda env: $CONDA_DEFAULT_ENV"
echo ""

# Create necessary directories
mkdir -p logs checkpoints_quick results records

echo "🚀 开始快速测试训练（3 epochs）..."
echo ""

python main.py \
  --train_samples 2000 \
  --eval_samples 500 \
  --epochs 3 \
  --batch_size 64 \
  --num_workers 8 \
  --lr 0.0005 \
  --warmup_epochs 1 \
  --eval_freq 1 \
  --save_freq 1 \
  --checkpoint_dir ./checkpoints_quick \
  --use_wandb \
  --wandb_project "dino-quick-test"

echo ""
echo "✅ 快速测试完成！"
echo "End: $(date)"
